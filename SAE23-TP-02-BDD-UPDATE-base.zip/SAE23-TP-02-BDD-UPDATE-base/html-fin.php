<?php
require_once('funcs.php');
if (isset($pdo)) $pdo=null;
cbPrintf('</body>');
cbPrintf('</html>');
exit();
?>
